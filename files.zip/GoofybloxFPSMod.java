package net.goofyblox.fps;

import net.fabricmc.api.ClientModInitializer;
import net.goofyblox.fps.performance.DynamicFPSController;
import net.goofyblox.fps.particles.ParticleLimiter;
import net.goofyblox.fps.culling.EntityCullingManager;
import net.goofyblox.fps.chunk.ChunkOptimizer;
import net.goofyblox.fps.entity.BlockEntityLimiter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GoofybloxFPSMod implements ClientModInitializer {

    public static final String MOD_ID = "goofybloxfps";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("=== Goofyblox FPS Engine v1.0.0 Loaded! ===");

        DynamicFPSController.init();
        ParticleLimiter.init();
        EntityCullingManager.init();
        ChunkOptimizer.init();
        BlockEntityLimiter.init();

        LOGGER.info("All FPS optimization modules initialized!");
    }
}
