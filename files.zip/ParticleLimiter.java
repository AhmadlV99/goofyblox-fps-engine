package net.goofyblox.fps.particles;

import net.goofyblox.fps.GoofybloxFPSMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.ParticlesMode;

/**
 * ParticleLimiter
 *
 * Monitors particle count and forces MINIMAL mode
 * if the game is struggling. Works together with
 * DynamicFPSController for particle management.
 *
 * Future: Hook into particle spawn events to cap
 * per-tick particle spawning at a configurable limit.
 */
public class ParticleLimiter {

    // Max allowed particles before forcing reduction
    private static final int PARTICLE_CAP = 5000;

    public static void init() {
        GoofybloxFPSMod.LOGGER.info("[ParticleLimiter] Particle limiter enabled. Cap: {}", PARTICLE_CAP);
        startMonitor();
    }

    private static void startMonitor() {
        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client != null && client.particleManager != null) {
                        // Get current FPS as a proxy metric
                        int fps = client.getCurrentFps();

                        // If FPS tanks, force particle reduction immediately
                        if (fps > 0 && fps < 15) {
                            client.options.getParticles().setValue(ParticlesMode.MINIMAL);
                            GoofybloxFPSMod.LOGGER.warn("[ParticleLimiter] Very low FPS ({}), forcing MINIMAL particles.", fps);
                        }
                    }
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception ignored) {}
            }
        }, "GoofyFPS-ParticleLimiter");

        thread.setDaemon(true);
        thread.start();
    }
}
