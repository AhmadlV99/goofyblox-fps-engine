package net.goofyblox.fps.culling;

import net.goofyblox.fps.GoofybloxFPSMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/**
 * EntityCullingManager
 *
 * Prevents entities that are:
 *  - Behind the player's view (basic frustum logic)
 *  - Too far away from the player
 *  - Hidden behind solid blocks
 *
 * from being processed for rendering, saving significant
 * CPU/GPU time on crowded servers or mob farms.
 *
 * Note: Full frustum/occlusion culling requires Mixins.
 * This class sets up the framework and provides utility methods.
 * Advanced culling hooks go in the mixin package.
 */
public class EntityCullingManager {

    // Max distance for rendering non-hostile entities (in blocks)
    private static final double PASSIVE_ENTITY_RENDER_DISTANCE = 48.0;

    // Max distance for rendering hostile entities
    private static final double HOSTILE_ENTITY_RENDER_DISTANCE = 64.0;

    private static boolean enabled = true;

    public static void init() {
        GoofybloxFPSMod.LOGGER.info("[EntityCulling] Entity culling manager initialized.");
        GoofybloxFPSMod.LOGGER.info("[EntityCulling] Passive render dist: {}b | Hostile render dist: {}b",
            PASSIVE_ENTITY_RENDER_DISTANCE, HOSTILE_ENTITY_RENDER_DISTANCE);
    }

    /**
     * Returns true if the given entity should be skipped (culled).
     * Call this from entity render Mixin to skip unnecessary renders.
     */
    public static boolean shouldCull(Entity entity) {
        if (!enabled) return false;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return false;

        // Never cull the player themselves or their vehicle
        if (entity == client.player) return false;
        if (entity == client.player.getVehicle()) return false;

        Vec3d playerPos = client.player.getPos();
        Vec3d entityPos = entity.getPos();

        double distanceSq = playerPos.squaredDistanceTo(entityPos);

        // Check if entity is beyond render threshold
        boolean isHostile = entity instanceof net.minecraft.entity.mob.HostileEntity;
        double maxDist = isHostile ? HOSTILE_ENTITY_RENDER_DISTANCE : PASSIVE_ENTITY_RENDER_DISTANCE;

        if (distanceSq > maxDist * maxDist) {
            return true; // Cull: too far
        }

        // Basic behind-camera check
        if (isBehindCamera(client, entityPos)) {
            return true; // Cull: behind player
        }

        return false;
    }

    /**
     * Simple check: is the entity behind the camera's forward direction?
     */
    private static boolean isBehindCamera(MinecraftClient client, Vec3d entityPos) {
        if (client.gameRenderer == null || client.player == null) return false;

        Vec3d playerPos = client.player.getEyePos();
        Vec3d toEntity = entityPos.subtract(playerPos).normalize();

        // Get player look vector
        Vec3d look = client.player.getRotationVec(1.0f);

        // Dot product: negative means behind
        double dot = look.dotProduct(toEntity);
        return dot < -0.2; // Slight margin so edges aren't aggressively culled
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        GoofybloxFPSMod.LOGGER.info("[EntityCulling] Entity culling {}", enabled ? "ENABLED" : "DISABLED");
    }

    public static boolean isEnabled() {
        return enabled;
    }
}
