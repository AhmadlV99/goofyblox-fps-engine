package net.goofyblox.fps.chunk;

import net.goofyblox.fps.GoofybloxFPSMod;
import net.minecraft.client.MinecraftClient;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ChunkOptimizer
 *
 * Provides multi-threaded chunk build queue management.
 * Dynamically adjusts the number of chunk builder threads
 * based on available CPU cores and current FPS performance.
 *
 * Benefits:
 *  - Faster chunk loading
 *  - Smoother world generation experience
 *  - Reduced stutter when entering new areas
 *
 * Thread count formula:
 *  - Default: max(1, availableProcessors / 2)
 *  - If FPS < 30: reduce to 1 thread to free CPU for render
 *  - If FPS > 60: scale up to max threads
 */
public class ChunkOptimizer {

    private static ExecutorService chunkBuilderPool;
    private static final AtomicInteger activeChunkTasks = new AtomicInteger(0);

    private static int currentThreadCount = 0;
    private static final int MAX_THREADS = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
    private static final int MIN_THREADS = 1;

    public static void init() {
        int initialThreads = Math.max(1, Runtime.getRuntime().availableProcessors() / 2);
        currentThreadCount = initialThreads;

        chunkBuilderPool = Executors.newFixedThreadPool(initialThreads, r -> {
            Thread t = new Thread(r, "GoofyFPS-ChunkBuilder");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1); // Slightly below normal
            return t;
        });

        GoofybloxFPSMod.LOGGER.info("[ChunkOptimizer] Initialized with {} chunk builder threads (max: {}).",
            initialThreads, MAX_THREADS);

        startAdaptiveManager();
    }

    /**
     * Submit a chunk build task to the optimized thread pool.
     */
    public static void submitChunkTask(Runnable task) {
        if (chunkBuilderPool == null || chunkBuilderPool.isShutdown()) return;

        activeChunkTasks.incrementAndGet();
        chunkBuilderPool.submit(() -> {
            try {
                task.run();
            } finally {
                activeChunkTasks.decrementAndGet();
            }
        });
    }

    /**
     * Adaptively manages thread count based on FPS.
     */
    private static void startAdaptiveManager() {
        Thread manager = new Thread(() -> {
            while (true) {
                try {
                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client != null) {
                        int fps = client.getCurrentFps();
                        int desired;

                        if (fps < 30) {
                            desired = MIN_THREADS;
                        } else if (fps > 60) {
                            desired = MAX_THREADS;
                        } else {
                            desired = Math.max(1, MAX_THREADS / 2);
                        }

                        if (desired != currentThreadCount) {
                            GoofybloxFPSMod.LOGGER.info(
                                "[ChunkOptimizer] Adjusting threads: {} -> {} (FPS: {})",
                                currentThreadCount, desired, fps
                            );
                            resizePool(desired);
                        }
                    }
                    Thread.sleep(10_000); // Check every 10 seconds
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    GoofybloxFPSMod.LOGGER.error("[ChunkOptimizer] Manager error: {}", e.getMessage());
                }
            }
        }, "GoofyFPS-ChunkManager");

        manager.setDaemon(true);
        manager.start();
    }

    private static void resizePool(int newSize) {
        if (chunkBuilderPool != null) {
            chunkBuilderPool.shutdown();
        }
        currentThreadCount = newSize;
        chunkBuilderPool = Executors.newFixedThreadPool(newSize, r -> {
            Thread t = new Thread(r, "GoofyFPS-ChunkBuilder");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        });
    }

    public static int getActiveTaskCount() {
        return activeChunkTasks.get();
    }

    public static int getCurrentThreadCount() {
        return currentThreadCount;
    }

    public static void shutdown() {
        if (chunkBuilderPool != null) {
            chunkBuilderPool.shutdownNow();
        }
    }
}
