package net.goofyblox.fps.entity;

import net.goofyblox.fps.GoofybloxFPSMod;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * BlockEntityLimiter
 *
 * Block entities (tile entities) like chests, furnaces,
 * signs, banners, and beacons each run render code every frame.
 * In bases with thousands of chests or farms with many furnaces,
 * this causes major FPS drops.
 *
 * This class provides:
 *  - shouldRenderBlockEntity(BlockEntity) check for Mixins
 *  - Configurable render distance per block entity type
 *  - Emergency cutoff when FPS is critically low
 */
public class BlockEntityLimiter {

    // Default max render distance for block entities (in blocks)
    private static double maxRenderDistance = 32.0;

    // Emergency distance when FPS < 20
    private static final double EMERGENCY_DISTANCE = 12.0;

    // Normal distance
    private static final double NORMAL_DISTANCE = 32.0;

    private static boolean emergencyMode = false;

    public static void init() {
        GoofybloxFPSMod.LOGGER.info("[BlockEntityLimiter] Initialized. Max render distance: {}b", maxRenderDistance);
        startMonitor();
    }

    /**
     * Should this block entity be rendered?
     * Hook this into block entity render Mixin.
     */
    public static boolean shouldRender(BlockEntity blockEntity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return true;

        BlockPos pos = blockEntity.getPos();
        Vec3d playerPos = client.player.getPos();

        double dx = playerPos.x - pos.getX();
        double dy = playerPos.y - pos.getY();
        double dz = playerPos.z - pos.getZ();
        double distSq = dx * dx + dy * dy + dz * dz;

        return distSq <= maxRenderDistance * maxRenderDistance;
    }

    /**
     * Monitor FPS and switch to emergency mode if needed.
     */
    private static void startMonitor() {
        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client != null) {
                        int fps = client.getCurrentFps();

                        if (fps > 0 && fps < 20 && !emergencyMode) {
                            emergencyMode = true;
                            maxRenderDistance = EMERGENCY_DISTANCE;
                            GoofybloxFPSMod.LOGGER.warn(
                                "[BlockEntityLimiter] Emergency mode! FPS: {} - Reducing block entity distance to {}b",
                                fps, EMERGENCY_DISTANCE
                            );
                        } else if (fps >= 40 && emergencyMode) {
                            emergencyMode = false;
                            maxRenderDistance = NORMAL_DISTANCE;
                            GoofybloxFPSMod.LOGGER.info(
                                "[BlockEntityLimiter] FPS recovered ({}). Restoring distance to {}b",
                                fps, NORMAL_DISTANCE
                            );
                        }
                    }
                    Thread.sleep(4000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception ignored) {}
            }
        }, "GoofyFPS-BlockEntityLimiter");

        thread.setDaemon(true);
        thread.start();
    }

    public static void setMaxRenderDistance(double distance) {
        maxRenderDistance = distance;
        GoofybloxFPSMod.LOGGER.info("[BlockEntityLimiter] Render distance set to {}b", distance);
    }

    public static double getMaxRenderDistance() {
        return maxRenderDistance;
    }

    public static boolean isEmergencyMode() {
        return emergencyMode;
    }
}
