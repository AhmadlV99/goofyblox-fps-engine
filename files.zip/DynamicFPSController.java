package net.goofyblox.fps.performance;

import net.goofyblox.fps.GoofybloxFPSMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * DynamicFPSController
 * 
 * Automatically adjusts Minecraft graphics settings based on current FPS.
 * Runs on a background thread every 5 seconds.
 * 
 * Tiers:
 *  - FPS >= 60 : Restore settings to balanced
 *  - FPS < 60  : Reduce view distance to 8
 *  - FPS < 40  : Reduce view distance to 6, disable clouds
 *  - FPS < 30  : Reduce view distance to 4, minimal particles
 *  - FPS < 20  : Fastest graphics, view distance 2, no particles
 */
public class DynamicFPSController {

    private static boolean running = false;

    // Thresholds
    private static final int FPS_GOOD     = 60;
    private static final int FPS_MEDIUM   = 40;
    private static final int FPS_LOW      = 30;
    private static final int FPS_CRITICAL = 20;

    public static void init() {
        if (running) return;
        running = true;

        Thread thread = new Thread(() -> {
            GoofybloxFPSMod.LOGGER.info("[DynamicFPSController] Started.");

            while (running) {
                try {
                    MinecraftClient client = MinecraftClient.getInstance();
                    if (client == null || client.options == null) {
                        Thread.sleep(5000);
                        continue;
                    }

                    int fps = client.getCurrentFps();

                    if (fps >= FPS_GOOD) {
                        // Restore to balanced settings
                        client.options.getViewDistance().setValue(12);
                        client.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.FANCY);
                        client.options.getParticles().setValue(ParticlesMode.ALL);
                        client.options.getGraphicsMode().setValue(GraphicsMode.FANCY);

                    } else if (fps < FPS_CRITICAL) {
                        // Emergency - fastest everything
                        client.options.getViewDistance().setValue(2);
                        client.options.getParticles().setValue(ParticlesMode.MINIMAL);
                        client.options.getGraphicsMode().setValue(GraphicsMode.FAST);
                        client.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);
                        GoofybloxFPSMod.LOGGER.warn("[DynamicFPS] CRITICAL FPS: {} - Emergency mode!", fps);

                    } else if (fps < FPS_LOW) {
                        // Low FPS
                        client.options.getViewDistance().setValue(4);
                        client.options.getParticles().setValue(ParticlesMode.DECREASED);
                        client.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.OFF);

                    } else if (fps < FPS_MEDIUM) {
                        // Medium-Low FPS
                        client.options.getViewDistance().setValue(6);
                        client.options.getCloudRenderMode().setValue(net.minecraft.client.option.CloudRenderMode.FAST);

                    } else {
                        // Slightly below good
                        client.options.getViewDistance().setValue(8);
                    }

                    // Save options after each adjustment
                    client.options.write();
                    Thread.sleep(5000);

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    GoofybloxFPSMod.LOGGER.error("[DynamicFPSController] Error: {}", e.getMessage());
                }
            }
        }, "GoofyFPS-DynamicController");

        thread.setDaemon(true);
        thread.start();
    }

    public static void stop() {
        running = false;
    }
}
